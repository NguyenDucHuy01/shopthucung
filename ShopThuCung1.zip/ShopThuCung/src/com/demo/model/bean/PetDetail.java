package com.demo.model.bean;

public class PetDetail extends Product  {
	private int productDetailPetId;
	private String height;
	private String weight;
	private String lifeExpectancy;
	private String furColor;
	private String petPersonality;
	private String takeCareOf;
	private String origin;
	
	public PetDetail() {

	}

	public PetDetail(int imageId, String imageName, String imageLink, int isDelete, int productId, String productName,
			double oldPrice, double currentPrice, String productDescription, int count, int categoryId,
			String createDay, int productDetailPetId, String height, String weight, String lifeExpectancy, String furColor,
			String petPersonality, String takeCareOf, String origin) {
		super(imageId, imageName, imageLink, isDelete, productId, productName, oldPrice, currentPrice, productDescription,
				count, categoryId, createDay);
		this.productDetailPetId = productDetailPetId;
		this.height = height;
		this.weight = weight;
		this.lifeExpectancy = lifeExpectancy;
		this.furColor = furColor;
		this.petPersonality = petPersonality;
		this.takeCareOf = takeCareOf;
		this.origin = origin;
	}

	public int getProductDetailPetId() {
		return productDetailPetId;
	}

	public void setProductDetailPetId(int productDetailPetId) {
		this.productDetailPetId = productDetailPetId;
	}

	public String getHeight() {
		return height;
	}

	public void setHeight(String height) {
		this.height = height;
	}

	public String getWeight() {
		return weight;
	}

	public void setWeight(String weight) {
		this.weight = weight;
	}

	public String getLifeExpectancy() {
		return lifeExpectancy;
	}

	public void setLifeExpectancy(String lifeExpectancy) {
		this.lifeExpectancy = lifeExpectancy;
	}

	public String getFurColor() {
		return furColor;
	}

	public void setFurColor(String furColor) {
		this.furColor = furColor;
	}

	public String getPetPersonality() {
		return petPersonality;
	}

	public void setPetPersonality(String petPersonality) {
		this.petPersonality = petPersonality;
	}

	public String getTakeCareOf() {
		return takeCareOf;
	}

	public void setTakeCareOf(String takeCareOf) {
		this.takeCareOf = takeCareOf;
	}

	public String getOrigin() {
		return origin;
	}

	public void setOrigin(String origin) {
		this.origin = origin;
	}
}
