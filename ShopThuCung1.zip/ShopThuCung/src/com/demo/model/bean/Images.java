package com.demo.model.bean;

public class Images {
	private int imageId;
	private String imageName;
	private String imageLink;
	private int isDelete;
	
	public Images() {

	}
	
	public Images(int imageId, String imageName, String imageLink, int isDelete) {
		this.imageId = imageId;
		this.imageName = imageName;
		this.imageLink = imageLink;
		this.isDelete = isDelete;
	}

	public int getImageId() {
		return imageId;
	}

	public void setImageId(int imageId) {
		this.imageId = imageId;
	}

	public String getImageName() {
		return imageName;
	}

	public void setImageName(String imageName) {
		this.imageName = imageName;
	}

	public String getImageLink() {
		return imageLink;
	}

	public void setImageLink(String imageLink) {
		this.imageLink = imageLink;
	}

	public int getIsDelete() {
		return isDelete;
	}

	public void setIsDelete(int isDelete) {
		this.isDelete = isDelete;
	}
}
