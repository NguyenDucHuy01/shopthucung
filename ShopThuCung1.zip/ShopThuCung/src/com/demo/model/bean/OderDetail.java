package com.demo.model.bean;

public class OderDetail extends Oder {
	private int oderDetailId;
	private int productId;
	private int oderId;
	private int count;
	private double price;
	private String productName;
	private String userName;
	
	public OderDetail() {

	}
	
	public OderDetail(int oderid, int userId, String fullName, String email, String phoneNumber, String tradingAddress,
			String status, double totalMoney, String createDay, int oderDetailId, int productId, int oderId, int count, double price,String productName,String userName) {
		super(oderid, userId, fullName, email, phoneNumber, tradingAddress, status, totalMoney, createDay);
		this.oderDetailId = oderDetailId;
		this.productId = productId;
		this.oderId = oderId;
		this.count = count;
		this.price = price;
		this.productName = productName;
		this.userName = userName;
	}

	public int getOderDetailId() {
		return oderDetailId;
	}

	public void setOderDetailId(int oderDetailId) {
		this.oderDetailId = oderDetailId;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public int getOderId() {
		return oderId;
	}

	public void setOderId(int oderId) {
		this.oderId = oderId;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}
	
}
