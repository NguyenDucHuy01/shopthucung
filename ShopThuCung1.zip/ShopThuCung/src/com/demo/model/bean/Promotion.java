package com.demo.model.bean;

public class Promotion {
	private int promotionId;
	private int promotionOfTypeId;
	private String promotionDate;
	private String promotionEndDate;
	private String promotionOfDescription;
	private String createDay;
	private int isDelete;
	
	public Promotion() {

	}
	
	public Promotion(int promotionId, int promotionOfTypeId, String promotionDate, String promotionEndDate,
			String promotionOfDescription, String createDay, int isDelete) {
		this.promotionId = promotionId;
		this.promotionOfTypeId = promotionOfTypeId;
		this.promotionDate = promotionDate;
		this.promotionEndDate = promotionEndDate;
		this.promotionOfDescription = promotionOfDescription;
		this.createDay = createDay;
		this.isDelete = isDelete;
	}
	
	public int getPromotionId() {
		return promotionId;
	}
	
	public void setPromotionId(int promotionId) {
		this.promotionId = promotionId;
	}
	
	public int getPromotionOfTypeId() {
		return promotionOfTypeId;
	}
	
	public void setPromotionOfTypeId(int promotionOfTypeId) {
		this.promotionOfTypeId = promotionOfTypeId;
	}
	
	public String getPromotionDate() {
		return promotionDate;
	}
	
	public void setPromotionDate(String promotionDate) {
		this.promotionDate = promotionDate;
	}
	
	public String getPromotionEndDate() {
		return promotionEndDate;
	}
	
	public void setPromotionEndDate(String promotionEndDate) {
		this.promotionEndDate = promotionEndDate;
	}
	
	public String getPromotionOfDescription() {
		return promotionOfDescription;
	}
	
	public void setPromotionOfDescription(String promotionOfDescription) {
		this.promotionOfDescription = promotionOfDescription;
	}
	
	public String getCreateDay() {
		return createDay;
	}
	
	public void setCreateDay(String createDay) {
		this.createDay = createDay;
	}
	
	public int getIsDelete() {
		return isDelete;
	}
	
	public void setIsDelete(int isDelete) {
		this.isDelete = isDelete;
	}
}
