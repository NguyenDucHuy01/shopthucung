package com.demo.model.bean;

public class Product extends Images {
	private int productId;
	private String productName;
	private double oldPrice;
	private double currentPrice;
	private String productDescription;
	private int count;
	private int categoryId;
	private String createDay;
	private Images images;
	public Product() {
		
	}

	public Product(int imageId, String imageName, String imageLink, int isDelete, int productId, String productName, double oldPrice, double currentPrice,
			String productDescription, int count, int categoryId,
			String createDay) {
		super(imageId, imageName, imageLink, isDelete);
		this.productId = productId;
		this.productName = productName;
		this.oldPrice = oldPrice;
		this.currentPrice = currentPrice;
		this.productDescription = productDescription;
		this.count = count;
		this.categoryId = categoryId;
		this.createDay = createDay;
	}

	public int getProductId() {
		return productId;
	}

	public void setProductId(int productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public double getOldPrice() {
		return oldPrice;
	}

	public void setOldPrice(double oldPrice) {
		this.oldPrice = oldPrice;
	}

	public double getCurrentPrice() {
		return currentPrice;
	}

	public void setCurrentPrice(double currentPrice) {
		this.currentPrice = currentPrice;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public int getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(int categoryId) {
		this.categoryId = categoryId;
	}

	public String getCreateDay() {
		return createDay;
	}

	public void setCreateDay(String createDay) {
		this.createDay = createDay;
	}

	public Images getImages() {
		return images;
	}

	public void setImages(Images images) {
		this.images = images;
	}
	
	
}
