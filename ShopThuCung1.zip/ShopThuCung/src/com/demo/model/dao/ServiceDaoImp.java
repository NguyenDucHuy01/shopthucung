package com.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.demo.model.bean.Service;

public class ServiceDaoImp implements ServiceDao {
	JdbcTemplate template;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public List<Service> getService() {
		return template.query("select * from service", new RowMapper<Service>() {
			public Service mapRow(ResultSet rs, int row) throws SQLException
			{
				Service service = new Service();
				
				service.setServiceId(rs.getInt(1));
				service.setServiceName(rs.getString(2));
				service.setServicePrice(rs.getDouble(3));
				service.setServiceDescription(rs.getString(4));
				service.setCreateDay(rs.getString(5));
				service.setIsDelete(rs.getInt(6));
				
				return service;
			}
		});
	}
	

}
