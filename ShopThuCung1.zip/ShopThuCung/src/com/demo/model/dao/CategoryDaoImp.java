package com.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.demo.model.bean.Category;

public class CategoryDaoImp implements CategoryDao {
	JdbcTemplate template;
	
	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public List<Category> getCategory() {
		return template.query("select * from category", new RowMapper<Category>() {
			public Category mapRow(ResultSet rs, int row) throws SQLException
			{
				Category category = new Category();
				category.setCategoryId(rs.getInt(1));
				category.setCategoryName(rs.getString(2));

				return category;
			}
		});
	}
}
