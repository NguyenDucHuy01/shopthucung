package com.demo.model.dao;

import java.util.List;

import com.demo.model.bean.Promotion_Product;

public interface Promotion_ProductDao {
	public int add(Promotion_Product promotion_Product);
	
	public int update(Promotion_Product promotion_Product);
	
	public int delete(int promotion_ProductId);
	
	public Promotion_Product getPromotion_ProductById(int promotion_ProductId);
	
	List<Promotion_Product> getPromotion_Product();
}
