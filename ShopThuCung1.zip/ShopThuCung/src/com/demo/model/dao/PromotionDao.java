package com.demo.model.dao;

import java.util.List;

import com.demo.model.bean.Promotion;

public interface PromotionDao {
	public int add(Promotion promotion);
	
	public int update(Promotion promotion);
	
	public int delete(int promotionId);
	
	public Promotion getPromotionByPromotionId(int promotionId);
	
	List<Promotion> getPromotion();
}
