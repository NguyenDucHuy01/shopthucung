package com.demo.model.dao;

import java.util.List;

import com.demo.model.bean.Oder;

public interface OderDao {
	public int add(Oder oder);

	List<Oder> getOder();
	
	public Oder getOderIdMax(int userId);	


}
