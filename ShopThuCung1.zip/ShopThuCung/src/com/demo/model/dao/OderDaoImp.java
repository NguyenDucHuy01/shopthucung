package com.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.demo.model.bean.Oder;

public class OderDaoImp implements OderDao {
	JdbcTemplate template;
	long millis = System.currentTimeMillis();
	java.sql.Date date = new java.sql.Date(millis);
	OderDao oderDao = null;

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public int add(Oder oder) {
		String sql = "insert into oder value(" + 0 + ", '" + oder.getUserId() + "', '" + oder.getFullName() + "', '"
				+ oder.getEmail() + "', '" + oder.getPhoneNumber() + "','" + oder.getTradingAddress() + "', '"
				+ oder.getStatus() + "', " + oder.getTotalMoney() + ", '" + date + "')";
		return template.update(sql);		
	}
	
	
	@Override
	public Oder getOderIdMax(int userId) {
		String sql = "SELECT Max(oderId) as oderId FROM oder WHERE userId = ?";
		return template.queryForObject(sql, new Object[] { userId },
				new BeanPropertyRowMapper<Oder>(Oder.class));
	}

	@Override
	public List<Oder> getOder() {
		String sql = "SELECT * FROM oder";
		return template.query(sql, new RowMapper<Oder>() {
			@Override
			public Oder mapRow(ResultSet rs, int row) throws SQLException {
				Oder oder = new Oder();

				oder.setOderId(rs.getInt(1));
				oder.setUserId(rs.getInt(2));
				oder.setFullName(rs.getString(3));
				oder.setEmail(rs.getString(4));
				oder.setPhoneNumber(rs.getString(5));
				oder.setTradingAddress(rs.getString(6));
				oder.setStatus(rs.getString(7));
				oder.setTotalMoney(rs.getDouble(8));
				oder.setCreateDay(rs.getString(9));

				return oder;
			}
		});
	}

}
