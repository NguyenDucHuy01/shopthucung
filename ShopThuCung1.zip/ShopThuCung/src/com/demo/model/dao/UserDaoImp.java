package com.demo.model.dao;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;

import com.demo.model.bean.User;

public class UserDaoImp implements UserDao {
	JdbcTemplate template;
	long millis=System.currentTimeMillis();  
	java.sql.Date date = new java.sql.Date(millis);  

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
		
	@Override
	public int add(User user) {
		String sql = "insert into users value('"+ 0 +"','"+ user.getUsername() +"','"+ user.getPassword() +"','"+user.getFullName()  +
				"','" + user.getBirthday()  +"','"+user.getAddress()  +"','"+user.getGender() +"','"+user.getEmail() + 
				"','" + user.getPhoneNumber() +"','"+ date  +"','"+user.getEnabled() +"','"+user.getIsDelete() + "')";
		return template.update(sql);
	}

	@Override
	public int update(User user) {
		String sql = "update users set username = '"+ user.getUsername() +"', password = '"+ user.getPassword() +"', fullName = '"+ user.getFullName() + 
				"', birthday = '"+ user.getBirthday() + "', address = '"+ user.getAddress() + "', gender = '"+ user.getGender() + 
				"', phoneNumber = '"+ user.getPhoneNumber() + "', createDay = '"+ date + "', enabled = "+ user.getEnabled() +
				", isDelete = 0 where userId = "+ user.getUserId();
		return template.update(sql);
	}

	@Override
	public int delete(int userId) {
		String sql = "update  users set isDelete = 1 where userId= "+ userId +"";
		return template.update(sql);
	}

	@Override
	public User getUserByUserId(int userId) {
		String sql = "select * from users where userId = ?";
		return template.queryForObject(sql, new Object[] {userId}, new BeanPropertyRowMapper<User>(User.class));
	}

	@Override
	public List<User> getUser() {
		return template.query("select * from users", new RowMapper<User>() {
			public User mapRow(ResultSet rs, int row) throws SQLException
			{
				User user = new User();
				user.setUserId(rs.getInt(1));
				user.setUsername(rs.getString(2));
				user.setPassword(rs.getString(3));
				user.setFullName(rs.getString(4));
				user.setBirthday(rs.getString(5));
				user.setAddress(rs.getString(6));
				user.setGender(rs.getString(7));
				user.setEmail(rs.getString(8));
				user.setPhoneNumber(rs.getString(9));
				user.setCreateDay(rs.getString(10));
				user.setEnabled(rs.getInt(11));
				user.setIsDelete(rs.getInt(12));
				
				return user;
			}
		});
	}

	@Override
	public User getUserByUsername(String username) {
		String sql = "select * from users where username = ?";
		return template.queryForObject(sql, new String[] { username }, new RowMapper<User>() {

			public User mapRow(ResultSet rs, int row) throws SQLException {
				User user = new User();
				user.setUserId(rs.getInt("userId"));
				user.setUsername(rs.getString("username"));
				user.setPassword(rs.getString("password"));
				user.setEnabled(rs.getInt("enabled"));
				return user;
			}

		});
	}

	@Override
	public List<String> getRolesByUsername(String username) {
		String sql = "select roles.roleName from users_roles join users ON users.userId = users_roles.userId JOIN roles ON users_roles.roleId = roles.roleId WHERE username = ?";
		return template.query(sql, new String[] { username }, new RowMapper<String>() {

			public String mapRow(ResultSet resultSet, int row) throws SQLException {
				return resultSet.getString("roleName");
			}

		});
	}
}
