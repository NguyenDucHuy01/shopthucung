package com.demo.model.dao;

import java.util.List;
import com.demo.model.bean.Category;

public interface CategoryDao {
	List<Category> getCategory();
}	
