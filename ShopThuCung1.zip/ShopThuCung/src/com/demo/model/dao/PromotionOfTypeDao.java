package com.demo.model.dao;

import java.util.List;

import com.demo.model.bean.PromotionOfType;

public interface PromotionOfTypeDao {
	public int add(PromotionOfType promotionOfType);
	
	public int update(PromotionOfType promotionOfType);
	
	public int delete(int promotionOfTypeId);
	
	public PromotionOfType getPromotionOfTypeById(int promotionOfTypeId);
	
	List<PromotionOfType> getPromotionOfType();
}
