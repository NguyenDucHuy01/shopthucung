package com.demo.model.dao;

import java.util.List;

import com.demo.model.bean.OderDetail;

public interface OderDetailDao {
	public int add(OderDetail oderDetail);
	
	List<OderDetail> getOdersCurrentDay();
	
	List<OderDetail> getOdersWeek();
	
	List<OderDetail> getOdersMonth();
	
	List<OderDetail> getOdersYear();
}	
