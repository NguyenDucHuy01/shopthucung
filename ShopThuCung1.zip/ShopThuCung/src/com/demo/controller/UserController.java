package com.demo.controller;

import java.util.List;

import javax.websocket.server.PathParam;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.demo.model.bean.User;
import com.demo.model.bean.Users_Roles;
import com.demo.model.dao.UserDao;
import com.demo.model.dao.Users_RolesDao;


@Controller
public class UserController {
	@Autowired
	private UserDao userDao;
	@Autowired
	private Users_RolesDao users_RolesDao;
	
	@RequestMapping("/admin")
	public String showform() {
		return "manager";
	}
	
	@RequestMapping("/viewuser/adduser")
	public String add(Model model) {
		model.addAttribute("command", new User());
		return "adduser";
	}
	
	@RequestMapping(value = "/viewuser/save", method = {RequestMethod.POST})
	public String save(@ModelAttribute("command") User user, @PathParam("password") String password, ModelMap model) {
		int enabled = 1;
		int delete = 0;
        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
        String encodedPassword = passwordEncoder.encode(password);
		user.setEnabled(enabled);
		user.setIsDelete(delete);
		user.setPassword(encodedPassword);
		userDao.add(user);
		model.addAttribute("user", user);
		
		Users_Roles userRole = new Users_Roles();
		int roleId = 1;
		
		
		User usera = userDao.getUserByUsername(user.getUsername());
		userRole.setUserId(usera.getUserId());
		userRole.setRoleId(roleId);
		
		users_RolesDao.add(userRole);
		return "redirect:/viewuser";
	}
	
	 @RequestMapping("/viewuser")
	 public String viewemp(Model model){    
		 model.addAttribute("command", new User());
	     List<User> list = userDao.getUser();
	     model.addAttribute("list",list);  
	     List<Users_Roles> users_Roles = users_RolesDao.getUsers_Roles();
	     model.addAttribute("users_Roles", users_Roles);  
	     return "usermanager";    
	 } 
	 
	 @RequestMapping(value="/viewuser/edituser/{userId}", method = {RequestMethod.GET})
	 public String edit(@PathVariable int userId, Model model) {
		 User user = userDao.getUserByUserId(userId);
		 model.addAttribute("command", user);
		 return "edituser";
	 }
	 
	 @RequestMapping(value = "/viewuser/editsave", method = {RequestMethod.POST})
	 public String editsave(@ModelAttribute("command") User user, @PathParam("password") String password) {
		 int enabled = 1;
			int delete = 0;
	        BCryptPasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
	        String encodedPassword = passwordEncoder.encode(password);
			user.setEnabled(enabled);
			user.setIsDelete(delete);
			user.setPassword(encodedPassword);
			userDao.update(user);
		return "redirect:/viewuser";
	}
	 
	 @RequestMapping(value = "/deleteuser/{userId}", method = {RequestMethod.GET})
	 public String delete(@PathVariable int userId) {
		 userDao.delete(userId);
		 return"redirect:/viewuser";
	 }
	 
	 /* Quản lí quyền tài khoản
	  * Hiển thị form thêm quyền tài khoản
	  */ 
	 @RequestMapping("/viewuser/addrole")
		public String addRole(Model model) {
		 model.addAttribute("command", new Users_Roles());
			return "addrole";
		}
		//Trả về trang quản lí tài khoản khi click vào nút save
		@RequestMapping(value = "/viewuser/saverole", method = {RequestMethod.POST})
		public String saveRole( @ModelAttribute("command") Users_Roles users_Roles) {
			users_RolesDao.add(users_Roles);
			return "redirect:/viewuser";
		}
		//Hiển thị form chỉnh sửa tài khoản theo id tài khoản.
		 @RequestMapping(value="/viewuser/editrole/{id}", method = {RequestMethod.GET})
		 public String editRole(@PathVariable int id, Model model) {
			 Users_Roles users_Roles = users_RolesDao.getUsers_RolesById(id);
			 model.addAttribute("command", users_Roles);
			 return "editrole";
		 }
			//Trả về trang quản lí tài khoản khi click vào nút save
		 @RequestMapping(value = "/viewuser/editsaverole", method = {RequestMethod.POST})
		 public String editsaveRole(@ModelAttribute("command") Users_Roles users_Roles) {
			users_RolesDao.update(users_Roles);
			return "redirect:/viewuser";
		}
		 
		//Xóa tài khoản dựa theo id tài khoản
		 @RequestMapping(value = "/deleterole/{id}", method = {RequestMethod.GET})
		 public String deleteRole(@PathVariable int id) {
			 users_RolesDao.delete(id);
			 return"redirect:/viewuser";
		 }
	 
}
